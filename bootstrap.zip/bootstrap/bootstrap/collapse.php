<?php
include_once "header.php";
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-2">
            <div class="card" style="width: 15.5rem;">
                <div class="card-header">
                    Navigation
                </div>
                <ul class="list-group list-group-flush">
                    <a href="login.php" class="list-group-item">login</a>
                    <a href="registration.php" class="list-group-item">Registration</a>
                    <a href="forgot_password.php" class="list-group-item">forgot password</a>
                </ul>
            </div>
        </div>
        <div class="col-lg-10">

            <div class="dropdown show">
                <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Dropdown link
                </a>

                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                    <a class="dropdown-item" href="#">Action</a>
                    <a class="dropdown-item" href="#">Another action</a>
                    <a class="dropdown-item" href="#">Something else here</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include_once "footer.php";
?>
