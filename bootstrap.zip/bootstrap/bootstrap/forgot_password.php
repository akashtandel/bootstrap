<?php include_once "header.php";?>
<div class="container">
    <div class="row">
        <div class="col-sm-4 login_form">
            <form>
                <h1 class="heading">Reset password</h1>
                <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Old Password</label>
                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="old Password">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">New Password</label>
                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="New Password">
                </div>
                <button type="submit" class="btn btn-primary">Reset</button>
                <div class="form-group">
                    <a href="login.php"  class="link"> login !! </a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <a href="registration.php"  class="link">New Registration ??</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php include_once "footer.php";?>