<?php include_once "header.php";?>

<div class="card text-center">
    <div class="card-header">
        Akash Tandel's Details
    </div>
    <div class="card-body">
        <h3 class="card-title">Akash Tandel</h3>
        <img class="card-img-top" src="../image/akash1.jpeg" alt="Card image">
        <p class="card-text">Technologies know :<br>
            <b class="text-primary"> javascript,jQuery,c,c++,c#,.net,asp.net,python,android,Flutter,php,github,arduino,HTML,HTML5,MySQL,Data Science,NLP,CodeIgniter,Wordpress</b>
        </p>
        <p class="card-text">Education : BCA,MCA</p>
        <p class="card-text">Age : 21</p>
        <p class="card-text">Address : 722,kakwadi,jolly street,kakwadi-Danti,valsad,396385</p>

    </div>
    <div class="card-footer text-danger">
        <a href="bootstrap_1.php" class="btn btn-primary">Go Back</a>
    </div>
</div>


<?php include_once "footer.php";?>
