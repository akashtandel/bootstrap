<html>
<head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <title>Bootstrap</title>
    <style>
        .container{
            background-color: #cccccc;
        }
        .container-fluid{
            background-color: #bee5eb;
        }
        .col-sm-8{
            background-color: #38b673;
        }
        .aa{
            background-color: #0f6674;
        }
        .ab{
            background-color: #bee5eb;
        }
        .pink{
            background-color: lightpink;
        }
        .blue{
            background-color: skyblue;
        }

    </style>
</head>
<body>
<!-- container with 3 part of screen -->
<div class="container">
    <div class="row">
        <div class="col-sm aa">
            One of three columns
        </div>
        <div class="col-sm ab">
            One of three columns
        </div>
        <div class="col-sm">
            One of three columns
        </div>
    </div>
</div>
<!--  container fluid -->
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-8">
            <?php include "../../php/form/php_validation.php";?>
        </div>
        <div class="col-sm-4">
            Hello 2
        </div>
    </div>
</div>
<!-- container xl -->
<div class="container">
    <div class="row">
        <div class="col-xl-4 border bg-danger">
            col-xl-4
        </div>
        <div class="col-xl-4 pink border">
            col-xl-4 pink
        </div>
        <div class="col-xl-4 blue border">
            col-xl-4 blue
        </div>
    </div>
</div>


<div class="container px-lg-5">
    <div class="row mx-lg-n5">
        <div class="col py-3 px-lg-5 border bg-light">Custom column padding</div>
        <div class="col py-3 px-lg-5 border bg-light">Custom column padding</div>
    </div>
</div>

<div class="container">
    <h4 class="mt-5">COC    New Trailer</h4>
    <div class="embed-responsive embed-responsive-16by9">
        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/itP2S-9ymyg"></iframe>
    </div>
</div>
<br>
<div class="container">
    <div class="row">
        <div class="col-xl pink">
            hello
        </div>
    </div>
</div>
<br>
<div class="container">
    <div class="row justify-content-md-center">
        <div class="col blue">
            1 of 2
        </div>
        <div class="col bg-secondary">
            2 of 2
        </div>
    </div>
    <div class="row">
        <div class="col bg-success">
            1 of 3
        </div>
        <div class="col pink">
            2 of 3
        </div>
        <div class="col-xl-8 aa">
            3 of 3
        </div>
    </div>
</div>
<br>
<br>

<div class="container">
    <div class="row justify-content-md-center">
        <div class="col col-lg-2">
            1 of 3
        </div>
        <div class="col-md-auto">
            Variable width content
        </div>
        <div class="col col-lg-2">
            3 of 3
        </div>
    </div>
    <div class="row">
        <div class="col">
            1 of 3
        </div>
        <div class="col-md-auto">
            Variable width content
        </div>
        <div class="col col-lg-2">
            3 of 3
        </div>
    </div>
</div>
<br><br><br>
<div class="container pink">
    <div class="row">
        <div class="col-sm">
            <?php include "../../index.php";?>
        </div>
        <div class="col-sm-8 blue">
        <?php include "../../php/form/php_vali.php";?>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>
</body>
</html>