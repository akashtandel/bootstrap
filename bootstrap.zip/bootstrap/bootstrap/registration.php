<?php include_once "header.php";?>
<div class="container">
    <div class="row">
        <div class="col-sm-4 login_form">
            <form>
                <h1 class="heading">Registration</h1>
                <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Password</label>
                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Re-enter Password</label>
                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Re-enter Password">
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
                <div class="form-group">
                    <a href="login.php"  class="link">login !!</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php include_once "footer.php";?>