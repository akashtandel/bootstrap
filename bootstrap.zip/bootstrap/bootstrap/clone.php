<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
          integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <title>Bootstrap</title>
</head>
<body>
<br>
<div class="container align-item-center">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page">MYTREE</li>
        </ol>
    </nav>
    <h4>Trending Products</h4>
    <div class="row row-cols-1 row-cols-md-2 ml-1 mr-1">
        <div class="col-md-3 m-d-1 shadow-lg radius-md">
            <div class="card">
                <img class="card-img-top" src="../image/akash1.jpeg"
                     alt="Card image">

                <div class="card-body">
                    <div class="card-title text-justify">
                        <strong> leather jacket</strong>
                    </div>
                    <div class="card-text text-justify">
                        <div class="row">
                            <div class="col-7">
                                <p>&#8377;.6000 <del>&#8377;.10000</del></p>
                            </div>
                            <div class="col-5">
                                <p class="text-danger"><small>(40% OFF)</small></p>
                            </div>
                        </div>
                    </div>
                    <hr />
                    <div class="row">
                        <div class="col-12 justify-content-center text-center">
                            <a href="details.html"
                               class="btn btn-default" target="_blank">View Details</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 radius-md shadow-lg">
            <div class="card">
                <img class="card-img-top" src="../image/akash2.jpeg"
                     alt="Card image">

                <div class="card-body">
                    <div class="card-title text-justify">
                        <strong> Red shades</strong>
                    </div>
                    <div class="card-text text-justify">
                        <div class="row">
                            <div class="col-7">
                                <p>&#8377;.6000 <del>&#8377;.10000</del></p>
                            </div>
                            <div class="col-5">
                                <p class="text-danger"><small>(40% OFF)</small></p>
                            </div>
                        </div>
                    </div>
                    <hr />
                    <div class="col-12 justify-content-center text-center">
                        <a href="details.html"
                           class="btn btn-default" target="_blank">View Details</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 radius-md shadow-lg">
            <div class="card">
                <img class="card-img-top" src="../image/akash3.jpeg"
                     alt="Card image">

                <div class="card-body">
                    <div class="card-title text-justify">
                        <strong> black shades</strong>
                    </div>
                    <div class="card-text text-justify">
                        <div class="row">
                            <div class="col-7">
                                <p>&#8377;.6000 <del>&#8377;.10000</del></p>
                            </div>
                            <div class="col-5">
                                <p class="text-danger"><small>(40% OFF)</small></p>
                            </div>
                        </div>
                    </div>
                    <hr />
                    <div class="col-12 justify-content-center text-center">
                        <a href="details.html"
                           class="btn btn-default" target="_blank">View Details</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 radius-md shadow-lg">
            <div class="card">
                <img class="card-img-top" src="../image/akash6.jpeg"
                     alt="Card image">

                <div class="card-body">
                    <div class="card-title text-justify">
                        <strong> Pepe jeans hoodie</strong>
                    </div>
                    <div class="card-text text-justify">
                        <div class="row">
                            <div class="col-7">
                                <p>&#8377;.6000 <del>&#8377;.10000</del></p>
                            </div>
                            <div class="col-5">
                                <p class="text-danger"><small>(40% OFF)</small></p>
                            </div>
                        </div>
                    </div>
                    <hr />
                    <div class="col-12 justify-content-center text-center">
                        <a href="details.html"
                           class="btn btn-default" target="_blank">View Details</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<br><br>
    <div class="row row-cols-1 row-cols-md-2 ml-1 mr-1">
        <div class="col-md-3 m-d-1 shadow-lg radius-md">
            <div class="card">
                <img class="card-img-top" src="../image/akash9.jpeg"
                     alt="Card image">

                <div class="card-body">
                    <div class="card-title text-justify">
                        <strong> Multi-color shirt</strong>
                    </div>
                    <div class="card-text text-justify">
                        <div class="row">
                            <div class="col-7">
                                <p>&#8377;.6000 <del>&#8377;.10000</del></p>
                            </div>
                            <div class="col-5">
                                <p class="text-danger"><small>(40% OFF)</small></p>
                            </div>
                        </div>
                    </div>
                    <hr />
                    <div class="row">
                        <div class="col-12 justify-content-center text-center">
                            <a href="details.html"
                               class="btn btn-default" target="_blank">View Details</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 radius-md shadow-lg">
            <div class="card">
                <img class="card-img-top" src="../image/akash10.jpeg"
                     alt="Card image">

                <div class="card-body">
                    <div class="card-title text-justify">
                        <strong> Red-white shirt</strong>
                    </div>
                    <div class="card-text text-justify">
                        <div class="row">
                            <div class="col-7">
                                <p>&#8377;.6000 <del>&#8377;.10000</del></p>
                            </div>
                            <div class="col-5">
                                <p class="text-danger"><small>(40% OFF)</small></p>
                            </div>
                        </div>
                    </div>
                    <hr />
                    <div class="col-12 justify-content-center text-center">
                        <a href="details.html"
                           class="btn btn-default" target="_blank">View Details</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 radius-md shadow-lg">
            <div class="card">
                <img class="card-img-top" src="../image/akash11.jpeg"
                     alt="Card image">

                <div class="card-body">
                    <div class="card-title text-justify">
                        <strong> blue shades</strong>
                    </div>
                    <div class="card-text text-justify">
                        <div class="row">
                            <div class="col-7">
                                <p>&#8377;.6000 <del>&#8377;.10000</del></p>
                            </div>
                            <div class="col-5">
                                <p class="text-danger"><small>(40% OFF)</small></p>
                            </div>
                        </div>
                    </div>
                    <hr />
                    <div class="col-12 justify-content-center text-center">
                        <a href="details.html"
                           class="btn btn-default" target="_blank">View Details</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 radius-md shadow-lg">
            <div class="card">
                <img class="card-img-top" src="../image/akash12.jpeg"
                     alt="Card image">

                <div class="card-body">
                    <div class="card-title text-justify">
                        <strong> white line shirt</strong>
                    </div>
                    <div class="card-text text-justify">
                        <div class="row">
                            <div class="col-7">
                                <p>&#8377;.6000 <del>&#8377;.10000</del></p>
                            </div>
                            <div class="col-5">
                                <p class="text-danger"><small>(40% OFF)</small></p>
                            </div>
                        </div>
                    </div>
                    <hr />
                    <div class="col-12 justify-content-center text-center">
                        <a href="details.html"
                           class="btn btn-default" target="_blank">View Details</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <h4 class="mt-5">Recent Products</h4>
    <div class="row row-cols-1 row-cols-md-2 ">
        <div class="col-md-3 m-d-1 shadow-lg radius-md">
            <div class="card">
                <img class="card-img-top" src="../image/akash5.jpeg"
                     alt="Card image">

                <div class="card-body">
                    <div class="card-title text-justify">
                        <strong> Pink Bag</strong>
                    </div>
                    <div class="card-text text-justify">
                        <div class="row">
                            <div class="col-7">
                                <p>&#8377;.6000 <del>&#8377;.10000</del></p>
                            </div>
                            <div class="col-5">
                                <p class="text-danger"><small>(40% OFF)</small></p>
                            </div>
                        </div>
                    </div>
                    <hr />
                    <div class="col-12 justify-content-center text-center">
                        <a href="details.html"
                           class="btn btn-default" target="_blank">View Details</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 radius-md shadow-lg">
            <div class="card">
                <img class="card-img-top" src="../image/akash4.jpeg"
                     alt="Card image">

                <div class="card-body">
                    <div class="card-title text-justify">
                        <strong> Black t-shirt</strong>
                    </div>
                    <div class="card-text text-justify">
                        <div class="row">
                            <div class="col-7">
                                <p>&#8377;.6000 <del>&#8377;.10000</del></p>
                            </div>
                            <div class="col-5">
                                <p class="text-danger"><small>(40% OFF)</small></p>
                            </div>
                        </div>
                    </div>
                    <hr />
                    <div class="col-12 justify-content-center text-center">
                        <a href="details.html"
                           class="btn btn-default" target="_blank">View Details</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 radius-md shadow-lg">
            <div class="card">
                <img class="card-img-top" src="../image/akash7.jpeg"
                     alt="Card image">

                <div class="card-body">
                    <div class="card-title text-justify">
                        <strong> White Rose shirt</strong>
                    </div>
                    <div class="card-text text-justify">
                        <div class="row">
                            <div class="col-7">
                                <p>&#8377;.6000 <del>&#8377;.10000</del></p>
                            </div>
                            <div class="col-5">
                                <p class="text-danger"><small>(40% OFF)</small></p>
                            </div>
                        </div>
                    </div>
                    <hr />
                    <div class="col-12 justify-content-center text-center">
                        <a href="details.html"
                           class="btn btn-default" target="_blank">View Details</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 radius-md shadow-lg">
            <div class="card">
                <img class="card-img-top" src="../image/akash8.jpeg"
                     alt="Card image">

                <div class="card-body">
                    <div class="card-title text-justify">
                        <strong> Pink jacket</strong>
                    </div>
                    <div class="card-text text-justify">
                        <div class="row">
                            <div class="col-7">
                                <p>&#8377;.7000 <del>&#8377;.10000</del></p>
                            </div>
                            <div class="col-5">
                                <p class="text-danger"><small>(40% OFF)</small></p>
                            </div>
                        </div>
                    </div>
                    <hr />
                    <div class="col-12 justify-content-center text-center">
                        <a href="details.html"
                           class="btn btn-default" target="_blank">View Details</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <h4 class="mt-5">Akash's Video</h4>
    <div class="embed-responsive embed-responsive-16by9">
        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/f93vLovGR2U"></iframe>
    </div>
<br><br><br>


<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>
</body>
</html>
