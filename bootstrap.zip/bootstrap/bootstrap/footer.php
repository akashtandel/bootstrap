</body>
<footer>
<div class="text-center p-1 fixed" style="background-color: rgba(0, 0, 0, 0.2);">
    © 2020 Copyright:
    <a class="text-white" href="aksh_tndl.php">Akash Tandel</a>
</div>
</footer>
</html>
