<?php include_once "header.php";?>
    <!-- main container-->
    <div class="row">
        <div class="col-lg-2">
            <div class="card" style="width: 16.5rem;">
                <div class="card-header">
                    Navigation
                </div>
                <ul class="list-group list-group-flush">
                    <a href="login.php" class="list-group-item">login</a>
                    <a href="registration.php" class="list-group-item">Registration</a>
                    <a href="forgot_password.php" class="list-group-item">forgot password</a>
                </ul>
            </div>

        </div>
        <div class="col-lg-10 example">
            <div class="row row-cols-1 row-cols-md-2 ml-1 mr-1 ">
                <?php for($i=0;$i<=15;$i++){?>
                <div class="col-md-3 radius-md shadow-lg">
                    <div class="card">
                        <img class="card-img-top" src="../image/akash10.jpeg" alt="Card image">
                        <div class="card-body">
                            <div class="card-title text-justify">
                                <strong> Red-white shirt</strong>
                            </div>
                            <div class="card-text text-justify">
                                <div class="row">
                                    <div class="col-7">
                                        <p>&#8377;.6000 <del>&#8377;.10000</del></p>
                                    </div>
                                    <div class="col-5">
                                        <p class="text-danger"><small>(40% OFF)</small></p>
                                    </div>
                                </div>
                            </div>
                            <hr />
                            <div class="col-12  text-center">
                                <a href="details.php" class="btn btn-default" >View Details</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>
</div>
<?php include_once "footer.php";?>
