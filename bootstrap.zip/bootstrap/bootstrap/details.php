<?php include_once "header.php";?>

<div class="card text-center">
    <div class="card-header">
        Product details
    </div>
    <div class="card-body">
        <h3 class="card-title">Red-white shirt</h3>
        <img class="card-img-top" src="../image/akash10.jpeg" alt="Card image">
        <p class="card-text">A shirt is a cloth garment for the upper body (from the neck to the waist).
            Originally an undergarment worn exclusively by men, it has become, in American English,
            a catch-all term for a broad variety of upper-body garments and undergarments. ...
            A shirt can also be worn with a necktie under the shirt collar.<br>
            <b class="text-primary">#whiteshirt #red #formal</b>
        </p>
        <p class="card-text">&#8377;.6000 <del>&#8377;.10000</del> <small class="text-danger">(40% OFF)</small></p>
        <p class="card-text text-danger">Harry up only few left  !!</p>

    </div>
    <div class="card-footer text-danger">
        <a href="bootstrap_1.php" class="btn btn-primary">Go Back</a>
        <a href="#" class="btn btn-primary">Add to cart</a>
    </div>
</div>


<?php include_once "footer.php";?>
