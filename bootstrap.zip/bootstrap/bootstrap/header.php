<html>
<head>
    <title>Bootstrap 1</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
          integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
            integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function() {
            $('.carousel').carousel({
                interval: 2000
            });
            $('#myCollapsible').collapse({
                toggle: false
            })
        });
    </script>
    <style>
        .title{
            font-size: xx-large;
        }
        .logout{
            text-align: right;
        }
        svg{
            height: 40px;
            width: 40px;
            margin-top: auto;
        }
        .head{
            background-color: rgba(0, 0, 0, 0.2);
        }
        .card-img-top{
            height: 17.2rem;
            width: 17.2rem;
        }
        body {
            /*overflow: hidden; !* Hide scrollbars *!*/
        }
        .example {
            height: 639px;
            overflow-y: scroll; /* Add the ability to scroll */
        }
        .example::-webkit-scrollbar {
            display: none;
        }
        .heading{
            text-align: center;
        }
        .login_form{
            margin:80px 0px 75px 420px;
            width: 50%;
            border-radius: 25px;
            border: 1px solid black;
            padding: 30px;
        }
        .fixed {
             position: fixed;
             width: 100%;
             bottom: 0;
         }
        img{
            width: 100%;
            height: 80%;
        }
    </style>
</head>
<div class="container-fluid" id="title">
    <!-- TO DO header-->
    <div class="row head">
        <div class="title col-sm-8">
          <a href="bootstrap_1.php" style="color: black;">Akash Tandel</a>
        </div>
        <div class="col-sm-4 logout">
            <a href="../index.php">
                <svg  xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16"><path fill-rule="evenodd" d="M0 2.75C0 1.784.784 1 1.75 1H5c.55 0 1.07.26 1.4.7l.9 1.2a.25.25 0 00.2.1h6.75c.966 0 1.75.784 1.75 1.75v8.5A1.75 1.75 0 0114.25 15H1.75A1.75 1.75 0 010 13.25V2.75zm9.42 9.36l2.883-2.677a.25.25 0 000-.366L9.42 6.39a.25.25 0 00-.42.183V8.5H4.75a.75.75 0 100 1.5H9v1.927c0 .218.26.331.42.183z"></path></svg >
            </a>
        </div>
    </div>
    <!-- navigation bar write below-->
    <nav class="navbar  navbar-expand-lg navbar-light bg-light">
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="bootstrap_1.php">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="registration.php">Registration</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link " href="forgot_password.php"role="button"  aria-expanded="false">
                        forgot password
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link " href="login.php" tabindex="-1" aria-disabled="false">login</a>
                </li>
            </ul>
        </div>
        <div>
            <a href="slide.php" class="badge badge-primary">Slide</a>
            <a href="collapse.php" class="badge badge-secondary">collapse</a>
            <a href="#" class="badge badge-success">Success</a>
            <a href="#" class="badge badge-danger">Danger</a>
            <a href="#" class="badge badge-warning">Warning</a>
            <a href="#" class="badge badge-info">Info</a>
            <a href="#" class="badge badge-light">Light</a>
            <a href="#" class="badge badge-dark">Dark</a>
        </div>
    </nav>
    <body>
