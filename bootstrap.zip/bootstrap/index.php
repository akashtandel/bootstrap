<html>
<head>
    <title>BOOTSTRAP</title>
    <style>
        body{
            background-color: seashell;
        }
        h1{
            color:lightseagreen;
            text-align: center;
        }
        table{
            background-color: antiquewhite;
            border:2px;
            border-color: black;
            width: 90%;
            padding: 25px;
            margin: 20px;
            text-align: center;
        }
    </style>
</head>
<body>
<h1>Bootstrap demo</h1>
<table border="1">
    <tr>
        <th>Name of topics</th>
        <th>links</th>
    </tr>
    <tr>
        <td>test</td>
        <td><a href="bootstrap/test.php">link</a></td>
    </tr>
    <tr>
        <td>clone</td>
        <td><a href="bootstrap/clone.php">link</a></td>
    </tr>
    <tr>
        <td>Bootstrap 1</td>
        <td><a href="bootstrap/bootstrap_1.php">link</a></td>
    </tr>
</table>
</body>
</html>